/**
 Name: Terry Dietrick
 Date: 08 Feb 2015
 Class & Section:  PWA1-Sec 01
 Comments: "Goal 3 debug"
 */
