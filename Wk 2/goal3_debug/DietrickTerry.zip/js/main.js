/**
 Name: Terry Dietrick
 Date: 15 Feb 2015
 Class & Section:  PWA1-Sec 01
 Comments: "Goal 3 debug wk 2"
 */
